% Autor   : Michal Lukac, xlukac05@stud.fit.vutbr.cz
% Projekt : Zpracovanie obrazu do predmetu ISS 2011/2012

% 1. uloha nacitanie obrazku a zaostrenie pomocou linearneho filtru
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
iptsetpref('UseIPPL',false);
I = imread('xlukac05.bmp');

% vytvorenie filtru
H1 = [-0.5 -0.5 -0.5;
    -0.5 5.0 -0.5;
    -0.5 -0.5 -0.5];

% zaostrenie
Izaostreny = imfilter(I,H1);
imwrite(Izaostreny,'step1.bmp');

% 2. uloha preklopenie obrazku okolo zvislej osy
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ipreklopeny = fliplr(Izaostreny);
imwrite(Ipreklopeny,'step2.bmp');

% 3. uloha aplikujte na obrazok medianovy filter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Imedianovy = medfilt2(Ipreklopeny,[5 5]);
imwrite(Imedianovy,'step3.bmp');

% 4. uloha rozmazanie obrazku
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
H2 = [ 1 1 1 1 1;
       1 3 3 3 1;
       1 3 9 3 1;
       1 3 3 3 1;
       1 1 1 1 1]/49;

% aplikovanie filtru
Irozmazany = imfilter(Imedianovy,H2);
imwrite(Irozmazany,'step4.bmp');

%5. uloha chyba v obraze medzi originalnym obrazkom a step4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Iquest5 = im2uint8(I);
Istep4 = im2uint8(Irozmazany);
Istep4f= fliplr(Istep4);

Iquest5d = double(Iquest5);
Istep4d = double(Istep4f);

%prejdeme cyklom pixel po pixelu
noise = double(0);
for (x=1:512)
    for (y=1:512)
        noise=noise+abs(double(Iquest5d(x,y))-double(Istep4d(x,y)));
    end;
end;

%podelime vsetkymy pixelami
noise = double(noise/(512*512));

%6.uloha roztiahnutie histogramu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%najdem si max a min hodnotu v histograme
max = 0;
min = 255;
for (x=1:512)
    for (y=1:512)
        if (max < Irozmazany(x,y))
            max = Irozmazany(x,y);
        end;
        if (min > Irozmazany(x,y))
            min = Irozmazany(x,y);
        end;
    end;
end;

max = double(max)/255;
min = double(min)/255;
imstep5 = double(Irozmazany);
hist = imadjust(Irozmazany,[min max],[0 1]);
hist1 = im2uint8(hist);
imwrite(hist1,'step5.bmp');

%7.uloha stredna hodnota a smerodatna odchylka
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
oldmean = mean2(imstep5);
newmean = mean2(hist);
oldstd = std2(imstep5);
newstd = std2(hist);

%8.uloha kvantizacia obrazu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N = 2;
a = 0;
b = 255;
IQ = zeros(512,512);
for k=1:512
    for j=1:512
        IQ(k,j) = round(((2^N)-1)*(double(hist(k,j))-a)/(b-a))*(b-a)/((2^N)-1)+a;
    end;
end;
IQ = uint8(IQ);
imwrite(IQ,'step6.bmp');